<?php
namespace app\controllers;
use Yii;
use yii\web\Controller;
use app\models\Movie;

class MovieController extends Controller
{
    public function actionForm()
    {
        $model = new Movie();
        $model->title = "-";
        
        if ($model->load(Yii::$app->request->post())) {
            // perintah untuk menyimpan ke database
            if ($model->save()){
                Yii::$app->session->setFlash('success', 'berhasil disimpan guys');
                return $this->redirect('index'); 
            }
            else{
                Yii::$app->session->setFlash('error', 'gagal disimpan guys');
            }
        }

        return $this->render('form',[
            'model' => $model,
        ]);
    }

    public function actionIndex()
    {
        // Booking vs User
        //$model = Booking::find()->one();
        //echo $model->user->name;

        $model = Movie::find()->all();
        return $this->render('index', [
            'model' => $model,
        ]);
    }

    public function actionView(int $id)
    {
        $model = Movie::find()->where([
            'id' => $id
        ])->one();
        if ($model==NULL){
            Yii::$app->session->setFlash('warning', 'data tidak ditemukan'); 
            return $this->redirect('index'); 
        }

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionUpdate(int $id)
    {
        $model = Movie::find()->where([
            'id' => $id
        ])->one();
        if ($model==NULL){
            Yii::$app->session->setFlash('warning', 'data tidak ditemukan'); 
            return $this->redirect('index'); 
        }

        //

        return $this->render('form', [
            'model' => $model,
        ]);
    }

    public function actionDelete(int $id)
    {
        $model = Movie::findOne($id);
        
        if ($model->delete()){
            Yii::$app->session->setFlash('success', 'data berhasil dihapus'); 
        }
        else{
            Yii::$app->session->setFlash('error', 'data gagal dihapus'); 
        }
        return $this->redirect('index'); 
    }
}
