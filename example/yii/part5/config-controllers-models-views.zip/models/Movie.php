<?php
namespace app\models;
use Yii;
use yii\db\ActiveRecord;

class Movie extends ActiveRecord
{
    
    public function rules()
    {
        return [
            [['title'], 'required'],
            [['title'], 'string', 'length' => [3,255]],
            [['description', 'genre'], 'safe'],
        ];
    }
}
