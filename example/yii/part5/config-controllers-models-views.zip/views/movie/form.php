<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
$this->title = 'Form Movie';
$this->params['breadcrumbs'][] = $this->title;
$form = ActiveForm::begin(); 
echo $form->field($model, 'title')->textInput();
echo $form->field($model, 'description')->textarea(); 
echo $form->field($model, 'genre')->textInput();

echo '<div class="form-group">';
echo Html::submitButton('<span class="glyphicon glyphicon-floppy-disk"></span> Submit', [
    'class' => 'btn btn-primary'
]);
echo " ";
echo Html::a('Batal', ['index'],['class'=>'btn btn-default']);
echo '</div>';
ActiveForm::end();