<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Form Movie';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="movie-form">
    <h1><?= Html::encode($this->title) ?></h1>
    <div class="row">
        <div class="col-md-6">
            <?php $form = ActiveForm::begin(); ?>
                <?= $form->field($model, 'title')->textInput() ?>
                <?= $form->field($model, 'description')->textarea() ?>
                <div class="form-group">
                    <?= Html::submitButton('Submit', [
                        'class' => 'btn btn-primary'
                    ]) ?>
                </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
