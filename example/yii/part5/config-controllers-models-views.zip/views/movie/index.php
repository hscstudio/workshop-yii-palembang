<?php
use yii\helpers\Html;
$this->title = 'List';
$this->params['breadcrumbs'][] = $this->title;
?>
<div>

    <?= Html::a('Tambah', ['form'],['class'=>'btn btn-primary']) ?>

    <table class="table table-striped table-bordered table-hover table-condensed">
    <thead>
        <tr>
            <th>Judul</th>
            <th>Genre</th>
            <th>Aksi</th>
        </th>
    </thead>
    <tbody>
    <?php
    foreach($model as $movie){
        echo "<tr>";
        echo "<td>".$movie->title."</td>";
        echo "<td>".$movie->genre."</td>";

        echo "<td>";
        echo "<div class='btn-group'>";
            echo Html::a('detail', ['view', 'id'=> $movie->id],[
                'class'=>'btn btn-primary btn-xs'
            ]);
            echo Html::a('update', ['update', 'id'=> $movie->id],[
                'class'=>'btn btn-warning btn-xs'
            ]);
            echo Html::a('delete', ['delete', 'id'=> $movie->id],[
                'class'=>'btn btn-danger btn-xs',
                'data' => [
                    'confirm' => 'Yakin mau dihapus?',
                ],
            ]);
        echo "</div>";
        echo "</td>";

        echo "</tr>";
    }
    ?>
    </tbody>
    </table>
</div>