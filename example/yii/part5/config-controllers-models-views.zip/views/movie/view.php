<?php
use yii\helpers\Html;
$this->title = 'Detail Movie';
$this->params['breadcrumbs'][] = ['label' => 'Movie', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div>
    <table class="table">
    <?php
    echo "<tr>";
        echo "<td> Judul </td>";
        echo "<td>".$model->title."</td>";
    echo "</tr>";
    echo "<tr>";
        echo "<td> Deskripsi </td>";
        echo "<td>".$model->description."</td>";
    echo "</tr>";
    echo "<tr>";
        echo "<td> Genre </td>";
        echo "<td>".$model->genre."</td>";
    echo "</tr>";
    ?>
    </table>
    <?= Html::a('Kembali', ['index'],['class'=>'btn btn-default']) ?>
</div>