<?php
use miloschuman\highcharts\Highcharts;

echo Highcharts::widget([
    'options' => [
    'chart' => ['type' => 'line' /* column */],
         'title' => ['text' => 'Booking Tickets Growth'],
         'xAxis' => [
             'categories' => ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
         ],
         'yAxis' => [
             'title' => ['text' => 'Total Booking']
         ],
         'series' => [
             ['name' => 'Booking', 'data' => [36, 79, 45, 83, 91, 102]],
         ]
    ]
 ]);

 echo Highcharts::widget([
    'options' => [
        'title' => ['text' => 'Booking Movie Share'],
        'series' => [
            [
                'type' => 'pie',
                'name' => 'Movie',
                'data' => [
                    ['Gundala', 45],
                    ['Warkop DKI Reborn', 26],
                    ['Others', 29]
                ],
            ]
        ],
    ]
 ]);

 echo Highcharts::widget([
    'options' => [
        'title' => ['text' => 'Booking Movie Share'],
        'series' => [
            [
                'type' => 'pie',
                'name' => 'Movie',
                'data' => $movie_data,
            ]
        ],
    ]
 ]);

 
  
