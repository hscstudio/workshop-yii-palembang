<?php 
$this->title = "Hello";
$this->params['breadcrumbs'][] = $this->title;
?>

<h1>Hello world!</h1>