<?php
use yii\helpers\ArrayHelper;
use app\models\Movie;
use kartik\widgets\Select2;
$movies=ArrayHelper::map(Movie::find()->all(),"id","title");
echo Select2::widget([
    'name' => 'movie',
    'value' => '',
    'data' => $movies,
    'options' => ['placeholder' => 'Select movie ...']
]);
?>
<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use kartik\widgets\DateTimePicker;
$form = ActiveForm::begin();
echo "<br>";
echo '<label class="control-label">Event Time</label>';
echo DateTimePicker::widget([
	'name' => 'event_time',
    'value' => date('Y-m-d H:i'),
    'type' => DateTimePicker::TYPE_COMPONENT_PREPEND,
    'layout' => '{picker}{input}{remove}',
    'removeButton' => ['position' => 'append'],
	'pluginOptions' => [
		'autoclose' => true,
		'format' => 'yyyy-mm-dd hh:ii'
	]
]);
echo "<br>";
echo Html::submitButton('Submit', ['class' => 'btn btn-primary']);
ActiveForm::end();