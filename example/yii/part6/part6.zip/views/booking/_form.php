<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use \yii\helpers\ArrayHelper;
use \app\models\Customer;
use \app\models\Schedule;
?>

<div class="booking-form">

    <?php $form = ActiveForm::begin(); ?>

    <?php
    $customers = ArrayHelper::map(Customer::find()->all(),"id","username");
    echo $form->field($model, 'user_id')->dropDownList($customers); 
    ?>

    <?php
    $schedules = ArrayHelper::map(Schedule::find()->all(),"id","start");
    echo $form->field($model, 'schedule_id')->dropDownList($schedules); 
    ?>

    <?= $form->field($model, 'amount')->textInput(['type'=>'number']) ?>

    <?= $form->field($model, 'status')->radioList([
        '1' => 'Publish', '0' => 'Draft',
    ]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
