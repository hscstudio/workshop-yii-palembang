<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Movie */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="movie-form">

    <?php $form = ActiveForm::begin(['options' => [
        'enctype' => 'multipart/form-data']
    ]); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'director')->textInput(['maxlength' => true]) ?>

    <div class="row">
        <div class="col-md-6">
        <?= $form->field($model, 'genre')->dropDownList([
            'HORROR'=>'HORROR', 
            'COMEDY'=>'COMEDY', 
            'ACTION'=>'ACTION', 
            'DRAMA'=>'DRAMA', 
            'ANIMATION'=>'ANIMATION', 
            'CRIME'=>'CRIME',
            'MUSIC'=>'MUSIC',
        ], ['prompt' => '- Pilih Genre']) ?>
        </div>
        <div class="col-md-6">
        <?= $form->field($model, 'rating')->dropDownList([
            'SU'=>'SU', 'TBC'=>'TBC', '13+'=>'13+', 
            '17+'=>'17+', '21+'=>'21+' 
        ], ['prompt' => '- Pilih Rating']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
        <?= $form->field($model, 'duration')->textInput(['type' => 'number']) ?>
        </div>
    </div>

    <?= $form->field($model, 'cover')->fileInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
