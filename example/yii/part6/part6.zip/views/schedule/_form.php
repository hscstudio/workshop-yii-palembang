<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use \yii\helpers\ArrayHelper;
use \app\models\Movie;
use \kartik\widgets\Select2;
use \kartik\widgets\SwitchInput;
use kartik\widgets\DateTimePicker;
?>
<div class="schedule-form">

    <?php $form = ActiveForm::begin(); ?>
    
    <?php
    $movies = ArrayHelper::map(Movie::find()->all(),"id","title");
    // echo $form->field($model, 'movie_id')->dropDownList($movies); 
    echo $form->field($model, 'movie_id')->widget(Select2::classname(), [
		'data' => $movies,
		'options' => ['placeholder' => 'Select a movie ...'],
		'pluginOptions' => [
			'allowClear' => true,
		],
	]);
    ?>

    <div class="row">
    <div class="col-md-6">
    <?php
    echo $form->field($model, 'start')->widget(
        DateTimePicker::classname(), [
        'options' => ['placeholder' => 'Enter start time ...'],
        'language' => 'id',
        'pluginOptions' => [
            'autoclose' => true,
            'format' => 'yyyy-mm-dd hh:ii:ss',
            'todayHighlight'=>true,
            'todayBtn'=>true,
        ]
    ]);
    ?>
    </div>
    <div class="col-md-6">
    <?= $form->field($model, 'room')->dropDownList([
        'Studio1'=>'Studio1', 
        'Studio2'=>'Studio2', 
        'Studio3'=>'Studio3', 
    ], ['prompt' => '- Pilih Room']) ?>
    </div>
    </div>

    <div class="row">
    <div class="col-md-6">
    <?= $form->field($model, 'quota')->textInput(['type'=>'number']) ?>
    </div>
    <div class="col-md-6">
    <?= $form->field($model, 'price')->textInput(['type'=>'number']) ?>
    </div>
    </div>

    <?php
    echo $form->field($model, 'status')->widget(SwitchInput::classname(), [
        'type' => SwitchInput::CHECKBOX,
        'pluginOptions'=>[
            'handleWidth'=>60,
            'onText'=>'Publish',
            'offText'=>'Draft'
        ]
    ]);
    ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
