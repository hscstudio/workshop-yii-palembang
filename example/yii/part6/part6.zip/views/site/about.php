<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About Us';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        This is the About page. You may modify the following file to customize its content:
    </p>

    <h2>Wah bisa diedit!</h2>

    <?php
    $users = [
        'Lionel Messi', 
        'Cristiano Ronaldo',
        'Neymar Jr.',
        'Paul Pogba',
        'Andrés Iniesta',
        'Alexis Sánchez',
        'Kylian Mbappé'
    ];
    ?>
    <ul>
    <?php
    foreach ($users as $user){
        echo "<li>".$user."</li>";
    }
    ?>
    </ul>
</div>
